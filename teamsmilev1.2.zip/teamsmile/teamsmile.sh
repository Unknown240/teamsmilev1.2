#!/system/xbin/bash
b='\033[1m'
u='\033[4m'
bl='\E[30m'
r='\E[31m'
g='\E[32m'
bu='\E[34m'
m='\E[35m'
c='\E[36m'
w='\E[37m'
endc='\E[0m'
enda='\033[0m'
blue='\e[1;34m'
cyan='\e[1;36m'
red='\e[1;31m'
echo "####################################"|lolcat
echo "$ TOOLS : Team Sm:)e                  "|lolcat
echo "$ MOD   : Clvnfrlnsyh               "|lolcat
echo "$ ◢ ◤ Team Sm:)e ◢ ◤               "|lolcat
echo "$ ★Sgb Team Reborn★                 "|lolcat
echo "####################################"|lolcat

sleep 1
echo "All Tools :"
echo "1. Tokopedia"
echo "2. Telkomsel"
echo "3. Oyo"
echo "4. Spam Call"
echo "5. Grab"
echo "6. Spam E-Mail"
echo "7. Tix-Id & Ovo"
echo "8. Bot Apk Yodo"
echo "9. Bom Email"
echo "10. PHISSING Shellphish"
echo "11. CAM HIDDEN SayCheese"
echo "12. LOCATER Seeker"
echo "0. Sign-Out"
echo "81.Information "
echo "Select Number :"
read mrrm
if [ $mrrm = 1 ] || [ $mrrm = 1 ]
then
clear
echo "Mod : Clvnfrlnsyh"
figlet "tokopedia"
php 1.php
fi

if
[ $mrrm = 2 ] || [ $mrrm = 2 ]
then
clear
echo "Mod : Clvnfrlnsyh"
toilet "Telkomsel"
php 2.php
fi

if [ $mrrm = 3 ] || [ $mrrm = 3 ]
then
clear
echo "\033[31;1m"
figlet "Oyo"
python 3.py
fi


if [ $mrrm = 4 ] || [ $mrrm = 4 ]
then
clear
toilet -f mono12 -F gay "Spam Call"
echo "Mod By : Clvnfrlnsyh"
php 4.php
fi

if
[ $mrrm = 5 ] || [ $mrrm = 5 ]
then
clear
toilet -f mono12 -F gay "Grab"
echo "Mod By : Clvnfrlnsyh"
python 5.py
fi

if
[ $mrrm = 6 ] || [ $mrrm = 6 ]
then
clear
toilet -f standard -F gay "Spam E-Mail"
echo "Mod By : Clvnfrlnsyh"
php 6.php
fi

if
[ $mrrm = 7 ] || [ $mrrm = 7 ]
then
clear
toilet -f standard -F gay "Tix-Id Ovo"
echo "Mod By : Clvnfrlnsyh"
php 7.php
fi

if
[ $mrrm = 8 ] || [ $mrrm = 8 ]
then
clear
toilet -f standard -F gay "Bot Yodo"
echo "Mod By : Clvnfrlnsyh"
php 8.php
fi

if
[ $mrrm = 9 ] || [ $mrrm = 9 ]
then
clear
toilet -f standard -F gay "Bom Email"
echo "Mod By : Clvnfrlnsyh"
python 9.py
fi

if [ $mrrm = 10 ] || [ $mrrm = 10 ]
then
clear
toilet -f mono12 -F gay "Phising"
echo "\033[30;1m"
bash shellphish.sh
fi

if [ $mrrm = 11 ] || [ $mrrm = 11 ]
then
clear
toilet -f mono12 -F gay "SayCheese"
echo "\033[30;1m"
bash saycheese.sh
fi

if [ $mrrm = 12 ] || [ $mrrm = 12 ]
then
clear
toilet -f mono12 -F gay "Seeker"
echo "\033[30;1m"
cd termux
python seeker.py
fi

if
[ $mrrm = 81 ] || [ $mrrm = 81 ]
then
clear
toilet -f slant --gay "Team Sm:)e"
echo "Name tools : Tools Sm:)e"
sleep 1
echo "Mod: Clvnfrlnsyh"
sleep 1
echo "Version : v1.2"
sleep 1
echo "Team: ★Sgb Team Reborn★"
sleep 1
echo "Spesial Thanks To: "
echo "Allah SWT"
echo "Team Sm:)e"
echo "4:39"
echo "TheLinuxChoice"
echo "All Member Army Bathalion's"
echo "All Team Coder / Recode Tools"
echo "All Member Sgb Team Reborn"
sleep 1
echo "DON'T FORGET FOR SM:)E"
sleep 7
sh teamsmile.sh
fi

if
[ $mrrm = 0 ] || [ $mrrm = 0 ]
then
echo "You Has Been Kick"
sleep 1
echo " Bye "
sleep 1
echo " See You "
sleep 1
fi

